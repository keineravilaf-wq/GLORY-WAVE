package dev.lelonio.square.backend.youtube

/**
 * The home page's own shelves: Christian music only.
 *
 * Instead of YouTube's personalised home, the page is this list, read from
 * the top a few shelves at a time. To change what the home shows, edit the
 * list at the bottom: add, remove or reorder entries and nothing else needs
 * to move.
 *
 * Each entry is one of:
 *  - [Artists]: a row of artist portraits, each found by searching its name.
 *  - [Songs]: a row of songs for a search. [Songs.artist], when set, keeps only
 *    the results credited to that artist, so a search for one name does not
 *    fill the row with someone else's songs.
 *  - [Playlists]: a row of public playlists for a search.
 *  - [DailyMix]: a playlist of the day for a genre; see [genres].
 */
internal object ChristianHome {

    sealed interface Shelf {
        val title: String
    }

    data class Artists(override val title: String, val names: List<String>) : Shelf

    data class Songs(
        override val title: String,
        val query: String,
        val artist: String? = null,
        val strapline: String? = null,
    ) : Shelf

    data class Playlists(override val title: String, val query: String) : Shelf

    /**
     * A playlist of the day for one genre.
     *
     * Several searches are pooled, then the pool is shuffled with a seed made
     * from today's date and the genre: the same list all day, a different one
     * tomorrow. At most two songs per artist, so one name cannot take it over.
     */
    data class DailyMix(
        override val title: String,
        val queries: List<String>,
        val strapline: String = "Se renueva cada día",
    ) : Shelf

    /** How many shelves are read per page; the list asks for the next page as it runs out. */
    const val PAGE_SIZE = 4

    private const val TAG = "Música cristiana"

    private fun artist(name: String, query: String = name) =
        Songs(title = name, query = query, artist = name, strapline = TAG)

    /** A day's seed for a shelf: stable for the day, different tomorrow. */
    fun seed(day: java.time.LocalDate, title: String): Long =
        day.toEpochDay() * 1_000_003L + title.hashCode()

    /**
     * The genres that get a mix each day: name, and the searches pooled for it.
     * Add a genre by adding a line; every search should say "cristiano" (or
     * "christian") so the pool stays Christian.
     */
    private val genres: List<Pair<String, List<String>>> = listOf(
        "Rock" to listOf("rock cristiano", "rock cristiano en español", "christian rock"),
        "Reggaeton" to listOf("reggaeton cristiano", "reggaeton cristiano nuevo"),
        "Trap" to listOf("trap cristiano", "trap cristiano nuevo"),
        "Rap y hip hop" to listOf("rap cristiano", "hip hop cristiano"),
        "R&B y soul" to listOf("r&b cristiano", "christian r&b", "soul cristiano"),
        "Gospel" to listOf("gospel", "gospel cristiano", "gospel en español"),
        "Adoración" to listOf("adoración cristiana", "worship en español"),
        "Alabanza" to listOf("alabanzas cristianas", "música de alabanza"),
        "Pop" to listOf("pop cristiano", "pop cristiano en español"),
        "Baladas" to listOf("baladas cristianas", "baladas cristianas románticas"),
        "Salsa y tropical" to listOf("salsa cristiana", "tropical cristiano"),
        "Bachata y merengue" to listOf("bachata cristiana", "merengue cristiano"),
        "Cumbia y vallenato" to listOf("cumbia cristiana", "vallenato cristiano"),
        "Regional mexicano" to listOf("regional mexicano cristiano", "mariachi cristiano"),
        "Electrónica" to listOf("electrónica cristiana", "christian EDM"),
        "Acústico" to listOf("acústico cristiano", "cristiana acústica"),
        "Instrumental" to listOf("piano cristiano instrumental", "música instrumental cristiana"),
        "Metal" to listOf("metal cristiano"),
        "Country" to listOf("country cristiano", "christian country"),
        "Para niños" to listOf("música cristiana para niños"),
    )

    /**
     * The home's shelves for [day]: the artists first, then the day's mixes
     * (in an order that changes daily) alternating with the fixed shelves.
     */
    fun shelvesFor(day: java.time.LocalDate): List<Shelf> {
        val mixes = genres
            .shuffled(kotlin.random.Random(day.toEpochDay()))
            .map { (name, queries) -> DailyMix(title = "Mix del día · $name", queries = queries) }
        val fixed = shelves
        val out = mutableListOf<Shelf>(fixed.first())
        val a = mixes.iterator()
        val b = fixed.drop(1).iterator()
        while (a.hasNext() || b.hasNext()) {
            if (a.hasNext()) out += a.next()
            if (b.hasNext()) out += b.next()
        }
        return out
    }

    /** The fixed shelves, before the mixes are woven in. */
    val shelves: List<Shelf> = listOf(
        Artists(
            title = "Artistas cristianos",
            names = listOf(
                "Daddy Yankee",
                "Alex Zurdo",
                "Israel Houghton",
                "Christine D'Clario",
                "Marcos Witt",
                "Miel San Marcos",
                "Redimi2",
                "Jesús Adrián Romero",
                "Marcos Barrientos",
                "Evan Craft",
                "Lilly Goodman",
                "Hillsong en Español",
                "Funky",
                "Barak",
                "Averly Morillo",
                "Un Corazón",
            ),
        ),
        Playlists("Música cristiana", "música cristiana"),

        // Daddy Yankee's catalogue is mostly reggaeton; the extra word steers
        // the search to his Christian songs. Adjust the query if it drifts.
        artist("Daddy Yankee", query = "Daddy Yankee cristiano"),
        artist("Alex Zurdo"),
        artist("Israel Houghton"),
        artist("Christine D'Clario"),
        artist("Marcos Witt"),

        Playlists("Adoración en español", "adoración en español"),
        artist("Miel San Marcos"),
        artist("Redimi2"),
        artist("Jesús Adrián Romero"),
        artist("Marcos Barrientos"),

        Playlists("Alabanzas", "alabanzas cristianas"),
        artist("Evan Craft"),
        artist("Lilly Goodman"),
        artist("Hillsong en Español"),
        artist("Funky"),

        Playlists("Rap y trap cristiano", "rap cristiano"),
        artist("Barak"),
        artist("Averly Morillo"),
        artist("Un Corazón"),
        artist("Kike Pavón"),

        Playlists("Para orar", "música cristiana para orar"),
        Playlists("Worship", "worship songs"),
    )
}
